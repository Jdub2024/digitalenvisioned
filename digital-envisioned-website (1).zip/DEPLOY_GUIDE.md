# Digital Envisioned — Deployment Guide

## Files in This Package

| File | Purpose |
|------|---------|
| `index.html` | Main website (61KB, complete one-page site) |
| `thank-you.html` | Post-form submission thank you page |
| `404.html` | Custom 404 error page (auto-redirects to home in 10s) |
| `sitemap.xml` | XML sitemap for Google Search Console |
| `robots.txt` | Crawl instructions for search engines |
| `.htaccess` | Apache config: HTTPS redirect, caching, compression |
| `deploy_ftp.py` | Python script for automated FTP upload |

---

## Option 1: Hostinger File Manager (EASIEST — No Technical Skills Needed)

1. Log in to **hpanel.hostinger.com**
2. Go to **Hosting** → click your domain
3. Click **File Manager**
4. Navigate to `public_html/` folder
5. Click **Upload** and upload all files from this package
6. For `.htaccess`: it's a hidden file — enable "Show hidden files" in File Manager
7. Visit `https://home.digitalenvisioned.net` to verify

---

## Option 2: FTP Upload

### Get FTP Credentials (Hostinger)
1. Log in to hpanel.hostinger.com
2. Go to **Hosting** → your domain → **FTP Accounts**
3. Note the FTP hostname, username, and password

### Using FileZilla (Free FTP Client)
1. Download FileZilla: https://filezilla-project.org/
2. Connect: Host = `ftp.digitalenvisioned.net`, Port = 21
3. Enter your FTP username and password
4. Navigate to `/public_html/` on the right panel
5. Drag all files from this package to the right panel
6. Make sure `.htaccess` (hidden file) is also uploaded

### Using the Python Script
1. Edit `deploy_ftp.py` and fill in:
   - `FTP_HOST` = your FTP hostname from hPanel
   - `FTP_USER` = your FTP username
   - `FTP_PASS` = your FTP password
2. Run: `python3 deploy_ftp.py`

---

## Option 3: GitHub Pages (If FTP Doesn't Work)

The site is already deployed at the Jdub2024/digitalenvisioned GitHub repo. You can use that as a backup URL while sorting out Hostinger access.

---

## After Deployment

### First-Time FormSubmit Setup
FormSubmit.co requires email confirmation the first time:
1. Submit the contact form on your site with a real email
2. Check newton@digitalenvisioned.net for a confirmation email from FormSubmit
3. Click the confirm link → forms will work permanently after that

### Add Google Analytics 4
1. Create a GA4 property at analytics.google.com
2. Get your Measurement ID (format: G-XXXXXXXXXX)
3. Find the comment `<!-- GA4 tag goes here -->` in index.html
4. Replace with:
```html
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

### Submit Sitemap to Google
1. Go to Google Search Console: https://search.google.com/search-console
2. Add property: `https://home.digitalenvisioned.net`
3. Go to Sitemaps → Add: `https://home.digitalenvisioned.net/sitemap.xml`

---

## What's New in This Version

✅ FormSubmit.co integration (replaces Formspree)  
✅ Full SEO meta tags (title, description, keywords)  
✅ Open Graph + Twitter Card tags  
✅ JSON-LD Local Business schema markup  
✅ GA4 placeholder  
✅ Blog/tips teaser section (3 SEO-optimized articles)  
✅ 4 testimonials with social proof  
✅ Urgency banner (animated shimmer effect)  
✅ Social sharing section  
✅ WhatsApp float button  
✅ DNS prefetch + font preload for performance  
✅ `loading="lazy"` on all images  
✅ Scroll reveal animations  
✅ Mobile hamburger menu  
✅ 3-tier pricing cards  
✅ Thank you page with next-steps  
✅ Custom 404 page with auto-redirect  
✅ sitemap.xml + robots.txt  
✅ .htaccess with HTTPS redirect, gzip, caching

---

*Digital Envisioned · Joshua Newton · Birmingham, AL*
*newton@digitalenvisioned.net · (205) 401-1124*
