#!/usr/bin/env python3
"""
Digital Envisioned — FTP Deployment Script
==========================================
Run this script to upload all website files to Hostinger via FTP.

Usage:
  1. Fill in your FTP credentials below (get from Hostinger hPanel > Hosting > FTP Accounts)
  2. Run: python3 deploy_ftp.py

FTP credentials can be found in Hostinger hPanel:
  - Log in to hpanel.hostinger.com
  - Go to Hosting > your domain > FTP Accounts
  - Create or use existing FTP account
"""

import ftplib
import os
import sys
from pathlib import Path

# ============================================================
# FILL IN YOUR HOSTINGER FTP CREDENTIALS
# ============================================================
FTP_HOST = "ftp.digitalenvisioned.net"   # Or your server IP (found in hPanel)
FTP_USER = ""                              # e.g., u123456789.ftp
FTP_PASS = ""                              # Your FTP password
FTP_PORT = 21
REMOTE_DIR = "/public_html"               # Or /domains/home.digitalenvisioned.net/public_html
# ============================================================

# Files to upload (in current directory)
FILES = [
    "index.html",
    "thank-you.html",
    "404.html",
    "sitemap.xml",
    "robots.txt",
    ".htaccess",
]

def upload_site():
    if not FTP_USER or not FTP_PASS:
        print("❌ ERROR: Please fill in FTP_USER and FTP_PASS before running this script!")
        print("   Get them from Hostinger hPanel > Hosting > FTP Accounts")
        sys.exit(1)

    script_dir = Path(__file__).parent
    
    print(f"\n🚀 Digital Envisioned FTP Deployment")
    print(f"   Host: {FTP_HOST}")
    print(f"   User: {FTP_USER}")
    print(f"   Remote: {REMOTE_DIR}")
    print()

    try:
        ftp = ftplib.FTP()
        ftp.connect(FTP_HOST, FTP_PORT, timeout=30)
        ftp.login(FTP_USER, FTP_PASS)
        print(f"✅ Connected to FTP server: {ftp.getwelcome()[:60]}")
        
        # Change to remote directory
        ftp.cwd(REMOTE_DIR)
        print(f"📁 Working in: {REMOTE_DIR}")
        print()
        
        # Upload each file
        success = 0
        failed = 0
        for filename in FILES:
            local_path = script_dir / filename
            if not local_path.exists():
                print(f"  ⚠️  Skipping (not found): {filename}")
                continue
            try:
                with open(local_path, 'rb') as f:
                    ftp.storbinary(f'STOR {filename}', f)
                size = local_path.stat().st_size
                print(f"  ✅ Uploaded: {filename} ({size:,} bytes)")
                success += 1
            except Exception as e:
                print(f"  ❌ Failed: {filename} — {e}")
                failed += 1
        
        ftp.quit()
        print()
        print(f"🎉 Deployment complete! {success} files uploaded, {failed} failed.")
        print(f"🌐 Visit: https://home.digitalenvisioned.net")
        
    except ftplib.all_errors as e:
        print(f"\n❌ FTP Error: {e}")
        print("\nTroubleshooting:")
        print("  • Double-check FTP_HOST, FTP_USER, FTP_PASS")
        print("  • Make sure FTP port 21 is not blocked by your firewall")
        print("  • Try passive mode: add 'ftp.set_pasv(True)' after ftp.login()")
        sys.exit(1)

if __name__ == "__main__":
    upload_site()
